# Requirements
database: MySQL

# Usage

test the server-side functions:
```
source <your-virtual-env-path>
pip install -r requirements.txt
python3 manage.py server
```

# Wait to solve
1. Order's total price need to save as an attribute.
2. Cart's total price is queried when loading the page.
